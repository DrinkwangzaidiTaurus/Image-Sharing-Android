package com.example.sharepictures;

import org.junit.Test;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() throws SQLException {
//        assertEquals(4, 2 + 2);
//        System.out.printf("1233456");
        Connection connection = Connect.getConnection("001for");
        if (connection!=null) {
            System.out.printf("连接成功");
        }
        Connect.insertUser("askdf","asdf123", "0123".getBytes());
    }
}